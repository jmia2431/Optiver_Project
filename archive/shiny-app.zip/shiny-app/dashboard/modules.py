# Import Modules
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from arch import arch_model
import matplotlib.pyplot as plt
import seaborn as sns

# Features Generation Functions
def calculate_wap(bid_price: pd.DataFrame, ask_price: pd.DataFrame, bid_size: pd.DataFrame, ask_size: pd.DataFrame) -> pd.DataFrame:
    
    wap = (bid_price*ask_size + ask_price*bid_size) / (bid_size + ask_size)
    return wap

def calculate_log_returns(df: pd.DataFrame) -> pd.DataFrame:
    df_copy = df.copy()
    df_copy = np.log(df_copy / df_copy.shift(1))
    return df_copy

def calculate_volatility(data):
    volatility = np.sqrt(np.sum(data**2))
    return volatility

# Interpolation for unchanged price
def interpolute_log_returns(df: pd.DataFrame) -> pd.DataFrame:
    full_seconds = pd.DataFrame({'seconds_in_bucket': range(600)})
    
    df_interpolated = pd.merge(full_seconds, df, on='seconds_in_bucket', how='left')
    df_interpolated['log_return'] = df_interpolated['log_return'].fillna(0)
    return df_interpolated

# Generate training and validation data
def generate_data(data: pd.DataFrame, validation_length:int, total_length:int=600):
    df = interpolute_log_returns(data)
    X = df['log_return'].loc[df['seconds_in_bucket'] < total_length-validation_length]*10000
    y = df['log_return'].loc[df['seconds_in_bucket'] >= total_length-validation_length]*10000
    return X,y


# Assesssing Funcitons
def calculate_MAPE(actual: float, predict: float) -> float:
    if actual == 0:
        return np.nan
    return np.abs(actual - predict)/(actual) * 100

def calculate_SMAPE(actual: float, predict: float) -> float:
    return 100*np.abs(predict - actual) / ((np.abs(actual) + np.abs(predict))/2)

# Price change count:
def count_price_changes(series):
    changes = series.diff().ne(0)
    
    return changes.sum()


# Pridiction Models Training: return -> model

# GARCH Model:
class GARCH_model():
    def __init__(self, train_X, validation_y) -> None:
        self.train_X = train_X
        self.y = validation_y
        self.result = None

    def predict(self, simulations:int=1000, p:int=1, q:int=1):
        model = arch_model(self.train_X, vol='Garch', p=p, q=q, rescale=False).fit(disp='off', show_warning=False)
        self.result = model.forecast(horizon=len(self.y), method='simulation', simulations=simulations)
        self.result = self.get_confidence_mean_result(self.result)
        return self.result

    def get_actual_volatility(self):
        return calculate_volatility(np.array(self.y))

    def get_confidence_mean_result(self, result):
        simulation_values = result.simulations.values
        lower_bounds = np.percentile(simulation_values, 2.5, axis=1)
        upper_bounds = np.percentile(simulation_values, 47.5, axis=1)
        confidence_interval_means = (lower_bounds + upper_bounds) / 2

        return confidence_interval_means
    
    def find_best_garch_order(self, max_p=4, max_q=4):
        best_aic = np.inf
        best_order = (0, 0)
        for p in range(1, max_p + 1):
            for q in range(1, max_q + 1):
                try:
                    model = arch_model(self.train_X, vol='Garch', p=p, q=q)
                    res = model.fit(disp='off')
                    if res.aic < best_aic:
                        best_aic = res.aic
                        best_order = (p, q)
                except Exception as e:
                    print(f"An error occurred while fitting model with p={p}, q={q}: {e}")
        return best_order, best_aic
    
    def assessing_model(self, method = 'mape'):
        actual = self.get_actual_volatility()
        predict = calculate_volatility(self.result)
        if method == 'mape':
            return calculate_MAPE(actual, predict)
        elif method == 'smape':
            return calculate_SMAPE(actual, predict)

# Regression Model:
class Regression_model():
    pass


# Multiple processing to booster the process
def process_stock_by_MAPE(stock_id):
    try:
        df = pd.read_csv(f'individual_book_train/stock_{stock_id}.csv')
        df['WAP'] = calculate_wap(df['bid_price1'], df['ask_price1'], df['bid_size1'], df['ask_size1'])
        df['log_return'] = calculate_log_returns(df['WAP'])
        df_grouped = df.groupby('time_id')
        
        results = []
        keys = []
        
        for group_name, group_df in df_grouped:
            train_X, validation_y = generate_data(group_df, 60)
            if calculate_volatility(validation_y) == 0:
                continue
            GARCH = GARCH_model(train_X, validation_y)
            GARCH.predict()
            mape = GARCH.assessing_model('mape')
            key = f'{stock_id}-{group_name}'
            
            results.append(mape)
            keys.append(key)
        
        return results, keys
    
    except FileNotFoundError:
        print(f"File not found: stock_{stock_id}.csv")
        return [], []
    
def process_stock_by_SMAPE(stock_id):
    try:
        df = pd.read_csv(f'individual_book_train/stock_{stock_id}.csv')
        df['WAP'] = calculate_wap(df['bid_price1'], df['ask_price1'], df['bid_size1'], df['ask_size1'])
        df['log_return'] = calculate_log_returns(df['WAP'])
        df_grouped = df.groupby('time_id')
        
        results = []
        keys = []
        
        for group_name, group_df in df_grouped:
            train_X, validation_y = generate_data(group_df, 60)
            if calculate_volatility(validation_y) == 0:
                continue
            GARCH = GARCH_model(train_X, validation_y)
            GARCH.predict()
            mape = GARCH.assessing_model('smape')
            key = f'{stock_id}-{group_name}'
            
            results.append(mape)
            keys.append(key)
        
        return results, keys
    
    except FileNotFoundError:
        print(f"File not found: stock_{stock_id}.csv")
        return [], []
    
# Clustering functions

def process_generate_time_id_feature(stock_id):
    try:
        df = pd.read_csv(f'individual_book_train/stock_{stock_id}.csv')
        df['WAP'] = calculate_wap(df['bid_price1'], df['ask_price1'], df['bid_size1'], df['ask_size1'])
        df = df.groupby('time_id')
        price_changes = []
        keys = []
        for group_name, group_df in df:
            price_change = count_price_changes(group_df['WAP'])
            price_changes.append(price_change)
            key = f'{stock_id}-{group_name}'
            keys.append(key)

        return price_changes, keys
    except FileNotFoundError:
        pass
        

def calculate_spreads_and_depths(group_df):
    features = {
        'mean_spread1': np.mean(group_df['ask_price1'] - group_df['bid_price1']),
        'mean_spread2': np.mean(group_df['ask_price2'] - group_df['bid_price2']),
        'std_spread1': (group_df['ask_price1'] - group_df['bid_price1']).std(),
        'std_spread2': (group_df['ask_price2'] - group_df['bid_price2']).std(),
        'mean_depth1': (group_df['bid_size1'] + group_df['ask_size1']).mean(),
        'mean_depth2': (group_df['bid_size2'] + group_df['ask_size2']).mean(),
        'std_depth1': (group_df['bid_size1'] + group_df['ask_size1']).std(),
        'std_depth2': (group_df['bid_size2'] + group_df['ask_size2']).std()
    }
    return features

def calculate_imbalances(group_df):
    features = {
        'mean_imbalance1': (group_df['bid_size1'] - group_df['ask_size1']).sum() / (group_df['bid_size1'] + group_df['ask_size1']).sum(),
        'mean_imbalance2': (group_df['bid_size2'] - group_df['ask_size2']).sum() / (group_df['bid_size2'] + group_df['ask_size2']).sum(),
        'std_imbalance1': ((group_df['bid_size1'] - group_df['ask_size1']) / (group_df['bid_size1'] + group_df['ask_size1'])).std(),
        'std_imbalance2': ((group_df['bid_size2'] - group_df['ask_size2']) / (group_df['bid_size2'] + group_df['ask_size2'])).std()
    }
    return features

def calculate_price_changes_and_volatility(group_df, df):
    features = {
        'price_change_count1': count_price_changes(group_df['WAP1']),
        'price_change_count2': count_price_changes(group_df['WAP2'])
        # 'volatility_9': calculate_volatility(group_df['log_return1'].loc[(df['seconds_in_bucket'] >= 480) & (df['seconds_in_bucket'] < 540)])
    }
    return features

def calculate_log_returns_metrics(log_returns):
    abs_log_returns = log_returns.abs()
    return {
        'abs_sum_log_returns': abs_log_returns.sum(),
        'mean_abs_log_returns': abs_log_returns.mean(),
        'std_log_returns': log_returns.std()
    }

def process_generate_features(stock_id, total_length=600, predict_length=60):
    try:
        df = pd.read_csv(f'./individual_book_train/stock_{stock_id}.csv')
        df = df.loc[df['seconds_in_bucket'] < total_length - predict_length]
        df['WAP1'] = calculate_wap(df['bid_price1'], df['ask_price1'], df['bid_size1'], df['ask_size1'])
        df['WAP2'] = calculate_wap(df['bid_price2'], df['ask_price2'], df['bid_size2'], df['ask_size2'])
        df['log_return1'] = calculate_log_returns(df['WAP1'])
        df['log_return2'] = calculate_log_returns(df['WAP2'])
        df = df.fillna(0)

        grouped_df = df.groupby("time_id")
        results = pd.DataFrame()

        for group_name, group_df in grouped_df:
            key = f'{stock_id}-{group_name}'
            features = {
                'ID': key,
                **calculate_spreads_and_depths(group_df),
                #**calculate_imbalances(group_df),
                **calculate_price_changes_and_volatility(group_df, df),
                **calculate_log_returns_metrics(group_df['log_return1']),
                **calculate_log_returns_metrics(group_df['log_return2'])
            }
            summary = pd.DataFrame([features])
            results = pd.concat([results, summary], ignore_index=True)

        return results
    except FileNotFoundError:
        pass