from shiny import App, reactive, render, ui
from shiny.types import FileInfo
from shinywidgets import output_widget, render_plotly
from dashboard.modules import GARCH_model
from faicons import icon_svg
import pandas as pd
import plotly.express as px
import time 

# Define the User Interface (UI)
app_ui = ui.page_sidebar(
    ui.sidebar(
        ui.input_file("stock_data", "Upload Data", accept=[".csv"], multiple=False), 

        ui.output_ui("dynamic_time_id")
    ), 

    ui.layout_column_wrap(
        ui.value_box(
            "V1", 
            ui.output_ui("volatility"),
            showcase = icon_svg("arrow-trend-up")
        ), 
        ui.value_box(
            "MAPE", 
            ui.output_ui("mape"),
            showcase= icon_svg("circle-xmark")
        ),
        ui.value_box(
            "SMAPE", 
            ui.output_ui("smape"),
            showcase = icon_svg("circle-xmark"),
        ),
        fill=False
    ),

    ui.layout_columns(
        ui.card(
            ui.card_header(
                # Render a plot for the historical and realised volatility
                "Volatility Projection",
                output_widget("projection"),
                full_screen = True
            )                
        ),
        ui.card( 
            ui.value_box("Selected Model", 
                        ui.output_ui("model"),
                        showcase=icon_svg("database")),
            ui.value_box("Run Time", 
                        ui.output_ui("runtime"),
                        showcase=icon_svg("hourglass-end"))
        ), 
        col_widths=[8, 4]
    ),

    title="Volatility Predictor",
    fillable=True
)   

# Define the server function
def server(input, output, session):
    @reactive.calc
    def parsed_file():
        # print("check")
        file: list[FileInfo] | None = input.stock_data()
        if file is None:
            return pd.DataFrame()
        return pd.read_csv(  # pyright: ignore[reportUnknownMemberType]
            file[0]["datapath"]
        )       

    @output
    @render.data_frame
    def view_data():        
        df = parsed_file()
        # print(f"Data Frame Type: {type(df)}")
        # print("\n\nPRINTING DATAFRAME BELOW")
        # print(df)

        return df.head(15)

    @render_plotly
    def projection():
        start_time = time.time()
        df = parsed_file()

        if "time_id" in df.columns and "seconds_in_bucket" in df.columns and "bid_price1" in df.columns:
            # Filter for rows selected time_id
            id_num = df[df["time_id"] == int(input.select_time_id())]
            
            # Create a scatter plot of bidprice1 against seconds
            fig = px.line(
                id_num, x="seconds_in_bucket", y="bid_price1", 
                title=f"Bid Price vs Seconds for Time ID {input.select_time_id()}"
            )
            end_time = time.time()
            runtime = end_time - start_time
            # session.send_input({"projection_runtime": runtime})  
            return fig
        return None
        
    @render.ui
    def dynamic_time_id():
        df = parsed_file()

        if "time_id" in df.columns:
            unique_time_ids = df["time_id"].unique().tolist()
            return ui.input_selectize(
                "select_time_id", 
                "Select Time ID", 
                choices = unique_time_ids, 
                selected = unique_time_ids[0] if unique_time_ids else None
            )
        return None 
        
    @output
    @render.ui
    def volatility():
        df = parsed_file()
        
        # if "time_id" in df.columns:
        #     df = df.loc[df['time_id'] == input.select_time_id()]
        #     return input.select_time_id()

        return "N/A"
    
    @output
    @render.ui
    def smape():
        df = parsed_file()
        if "bid_price1" in df.columns:
            vol = df["bid_price1"].std()  # standard deviation
            return f"{vol:.2f}"
        return "N/A"
    
    @output
    @render.ui
    def mape():
        df = parsed_file()
        if "bid_price1" in df.columns:
            vol = df["bid_price1"].std()  # standard deviation
            return f"{vol:.2f}"
        return "N/A"
    

    
    # @output 
    # @render.ui
    # def runtime():
    #     runtime = input.get("projection_runtime", 0)  
    #     return f"{runtime:.2f} seconds"   

    
# Create the Shiny App Instance
app = App(app_ui, server)

# Run the App
if __name__ == "__main__":
    app.run()

